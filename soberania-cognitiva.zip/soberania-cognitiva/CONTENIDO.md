# Guía simple — Ghost IndioYori (theme v1.4.1)

Sitio: https://indioyori.ghost.io  

Nombres claros en español. Sin renombres raros.  
Pendiente para después: **Tezcatlipoca Digital** (imágenes).

---

## Páginas del menú

| Label | URL | Template |
|---|---|---|
| Inicio | `/` | (portada) |
| Archivo | `/archivo/` | Archivo |
| Manifiesto | `/manifiesto/` | Manifiesto |
| Talleres | `/talleres/` | Talleres |
| Comunidad | `/comunidad/` | Comunidad |
| Membresía | `/membresia/` | Membresía |
| Contacto | `/contacto/` | Contacto |

**Hero:** Archivo · Manifiesto · Talleres  

**Secondary (filtros):** Análisis `/tag/nota/` · Video `/tag/video/` · Podcast `/tag/podcast/` · Territorio `/tag/territorio/`

---

## Acceso

| | Sin cuenta | Cuenta gratis | Membresía $350 |
|---|---|---|---|
| Leer el archivo y el sitio | sí | sí | sí |
| Comentar | — | sí | sí |
| Chat general | — | sí | sí |
| Chat exclusivo + espacio de trabajo | — | — | sí |

---

## Texto de Membresía (el que ya lleva el theme)

> El archivo sigue libre.  
> La membresía da acceso a un espacio de trabajo para quien necesita información más especializada: bases de arquitecturas RAG soberanas, análisis de datos con criterio, protocolos para organizar conocimiento y defensa del territorio, y marcos de geopolítica del conocimiento aplicados a proyectos reales.  
> Si defiendes activamente el territorio y no puedes pagar la membresía, escríbeme.  
> **$350 MXN al mes.**  
> **Apoya el proyecto** (botón aparte, si no tomas membresía pero quieres aportar dinero).

En Ghost: página título **Membresía**, slug `membresia`, template **Membresía**.  
Membership: tier Free + tier **Membresía · 350 MXN/mes**.

---

## Theme

Descarga:  
https://github.com/FronterIA-Lab/Blog_Indioyori/raw/cursor/ghost-diseno-contenido-5ed3/soberania-cognitiva.zip  

Design → Upload → Activate.
